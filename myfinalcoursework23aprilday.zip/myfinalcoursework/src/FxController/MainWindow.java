package FxController;

import javafx.event.ActionEvent;
import javafx.scene.control.*;

import java.sql.SQLException;

public class MainWindow {

    public TreeView bookList;
    public ListView commentsBook;
    public ListView shopBookList;
    public TextField searchTitle;
    public DatePicker searchPublish;
    public TextField searchAuthor;
    public ComboBox searchGenre;
    public TextField bookTitle;
    public TextArea bookDesc;
    public DatePicker pubDate;
    public TextField pgNum;
    public TextField edition;
    public ComboBox genre;
    public TextArea authors;
    public MenuItem editItem;
    public MenuItem viewInfoItem;
    public TextArea bookInfoField;
    public TreeView orderList;

    public void addBook(ActionEvent event) throws SQLException {

    }

}

/*package com.example.demo;

import com.example.demo.dsbook.Book;
import com.example.demo.dsbook.Genre;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;


import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class MainWindowController implements Initializable {

    public TreeView bookList;
    public ListView commentsBook;
    public ListView shopBookList;
    public TextField searchTitle;
    public DatePicker searchPublish;
    public TextField searchAuthor;
    public ComboBox searchGenre;
    public TextField bookTitle;
    public TextArea bookDesc;
    public DatePicker pubDate;
    public TextField pgNum;
    public TextField edition;
    public ComboBox genre;
    public TextArea authors;
    public MenuItem editItem;
    public MenuItem viewInfoItem;
    public TextArea bookInfoField;
    public TreeView orderList;

    public void addBook(ActionEvent event) throws SQLException {

        Book book = new Book(bookTitle.getText(), pubDate.getValue(), Integer.parseInt(pgNum.getText()), authors.getText(), Integer.parseInt(edition.getText()), bookDesc.getText(), Genre.SCI_FI);
      /*
        //Connect to db
        Connection connection = DatabaseOperations.connectToDatabase();
        String insertQuery = "INSERT INTO book(`book_title`, `publish_date`, `page_num`, `authors`, `edition`, `description`, `genre`) VALUES(?,?,?,?,?,?,?)";
        PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
        preparedStatement.setString(1, book.getBookTitle());
        preparedStatement.setDate(2, Date.valueOf(book.getPublishDate()));
        preparedStatement.setInt(3, book.getPageNum());
        preparedStatement.setString(4, book.getAuthors());
        preparedStatement.setInt(5, book.getEdition());
        preparedStatement.setString(6, book.getDescription());
        preparedStatement.setString(7, String.valueOf(book.getGenre()));
        preparedStatement.execute();
        DatabaseOperations.disconnectFromDatabase(connection, preparedStatement);
        //Insert Query
        //run query
        //close connection
        refreshTable();
    }

private void refreshTable() {
        shopBookList.getItems().clear();
        ArrayList<Book> books = DatabaseOperations.getAllBooksFromDb();
        books.forEach(b -> shopBookList.getItems().add(b));
        }

@Override
public void initialize(URL location, ResourceBundle resources) {
        refreshTable();
        }
        }*/