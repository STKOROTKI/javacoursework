package FxController;

import dsbook.Individual;
import dsbook.LegalPerson;
import dsbook.UserType;
import HibernateControllers.UserHibernate;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Persistence;
import javax.persistence.EntityManagerFactory;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import static utils.JavaFxUtils.alertMessage;

@NoArgsConstructor
public class SignUpController implements Initializable {
    @FXML
    public TextField loginFi;
    @FXML
    public PasswordField pswF;
    @FXML
    public ComboBox roleBox;
    @FXML
    public RadioButton individualRadio;
    @FXML
    public ToggleGroup userType;
    @FXML
    public RadioButton legalRadio;
    @FXML
    public TextField nameF;
    @FXML
    public TextField surnameF;
    @FXML
    public TextField emailF;
    @FXML
    public TextField comTitleF;
    @FXML
    public TextField comAddressF;
    @FXML
    public TextField comRepF;
    @FXML
    public TextField userpostfi;
    @FXML
    public TextField comPhoneF;
    @FXML
    public TextField phonef;


    EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("bookshop");
    UserHibernate userHibController = new UserHibernate(entityManagerFactory);


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        comAddressF.setDisable(true);
        comRepF.setDisable(true);
        comTitleF.setDisable(true);
        comPhoneF.setDisable(true);
        roleBox.getItems().addAll(UserType.Admin, UserType.Customer, UserType.Employee);
        changeFields();
    }

    public void saveAndReturn() throws IOException {

        if (individualRadio.isSelected()) {
            userHibController.createUser(new Individual(UserType.valueOf(roleBox.getSelectionModel().getSelectedItem().toString()),loginFi.getText(),pswF.getText(),emailF.getText(),userpostfi.getText(),phonef.getText(),nameF.getText(),surnameF.getText()));

        } else {
            userHibController.createUser(new LegalPerson(UserType.valueOf(roleBox.getSelectionModel().getSelectedItem().toString()), loginFi.getText(), pswF.getText(), emailF.getText(), userpostfi.getText(), phonef.getText(), comTitleF.getText(), comAddressF.getText(), comRepF.getText(), phonef.getText()));
        }
        alertMessage("User created successfully.");
        returnToPrevious();
    }

    private void returnToPrevious() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(StartController.class.getResource("login-window.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root);

        Stage stage = (Stage) loginFi.getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    public void returnToLogin() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(StartController.class.getResource("/demo/Start.fxml"));
        Parent parent = fxmlLoader.load();
        Scene scene = new Scene(parent);
        Stage stage = (Stage) loginFi.getScene().getWindow();
        stage.setTitle("Book store");
        stage.setScene(scene);
        stage.show();
    }


    public void changeFields() {
        if (individualRadio.isSelected()) {
            nameF.setDisable(false);
            surnameF.setDisable(false);
            emailF.setDisable(false);
            userpostfi.setDisable(false);
            phonef.setDisable(false);

            comTitleF.setDisable(true);
            comAddressF.setDisable(true);
            comRepF.setDisable(true);
            comPhoneF.setDisable(true);
        } else {
            nameF.setDisable(true);
            surnameF.setDisable(true);
            emailF.setDisable(true);
            userpostfi.setDisable(true);
            phonef.setDisable(true);

            comTitleF.setDisable(false);
            comAddressF.setDisable(false);
            comRepF.setDisable(false);
            comPhoneF.setDisable(false);
        }
    }


}


/*package FxController;

import HibernateControllers.UserHibernate;
import dsbook.Individual;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import org.hibernate.usertype.UserType;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class SignUpController implements Initializable {
    @FXML
    public TextField loginF;
    @FXML
    public PasswordField pswF;
    @FXML
    public ComboBox roleBox;
    @FXML
    public RadioButton individualRadio;
    @FXML
    public ToggleGroup userType;
    @FXML
    public RadioButton legalRadio;
    @FXML
    public TextField nameF;
    @FXML
    public TextField surnameF;
    @FXML
    public TextField emailF;
    @FXML
    public TextField comTitleF;
    @FXML
    public TextField comAddressF;
    @FXML
    public TextField comRepF;
    @FXML
    public DatePicker birthdatepick;

    EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("BookShop");
    UserHibernate userHibController = new UserHibernate(entityManagerFactory);


  public void saveAndReturn() throws IOException {
     if (individualRadio.isSelected()) {
          userHibController.createUser(new Individual(loginF.getText(),pswF.getText(), UserType.valueOf(roleBox.getSelectionModel().getSelectedItem().toString()),nameF.getText(),surnameF.getText()));
           returnToLogin();
        }
  }

    public void returnToLogin() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(StartController.class.getResource("../demo/Start.fxml"));
        Parent parent = fxmlLoader.load();
        Scene scene = new Scene(parent);
        Stage stage = (Stage) loginF.getScene().getWindow();
        stage.setTitle("Book store");
        stage.setScene(scene);
        stage.show();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        roleBox.getItems().addAll(UserType.ADMIN, UserType.CUSTOMER, UserType.EMPLOYEE);
        changeFields();
    }

    public void changeFields() {
        if (individualRadio.isSelected()) {
            nameF.setDisable(false);
            surnameF.setDisable(false);
            emailF.setDisable(false);

            comTitleF.setDisable(true);
            comAddressF.setDisable(true);
            comRepF.setDisable(true);
        } else {
            nameF.setDisable(true);
            surnameF.setDisable(true);
            emailF.setDisable(true);

            comTitleF.setDisable(false);
            comAddressF.setDisable(false);
            comRepF.setDisable(false);
        }
    }
}*/