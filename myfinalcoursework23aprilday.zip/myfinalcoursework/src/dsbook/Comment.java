package dsbook;

public class Comment {
}
