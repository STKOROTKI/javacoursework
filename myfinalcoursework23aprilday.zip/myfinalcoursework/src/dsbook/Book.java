package dsbook;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.List;

@Getter
@Setter
@Entity
@NoArgsConstructor
//@Data

public class Book {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private int id;
    private String bookTitle;
    private LocalDate publishDate;
    private int pageNum;
    private String authors;
    private int edition;
    private String description;
    private Genre genre;

//    @Transient
//    private boolean available;
//    @ManyToMany(mappedBy = "items", cascade = {CascadeType.PERSIST, CascadeType.MERGE})
//    @OrderBy("id ASC")
//    @LazyCollection(LazyCollectionOption.FALSE)
//    private List<Order> inCart;
//
//    @OneToMany(mappedBy = "bookComment", cascade = {CascadeType.PERSIST, CascadeType.MERGE}, orphanRemoval = true)
//    @OrderBy("id ASC")
//    @LazyCollection(LazyCollectionOption.FALSE)
//    private List<Comment> comments;



    public Book(String bookTitle, LocalDate publishDate, int pageNum, String authors, int edition, String description, Genre genre) {
        this.bookTitle = bookTitle;
        this.publishDate = publishDate;
        this.pageNum = pageNum;
        this.authors = authors;
        this.edition = edition;
        this.description = description;
        this.genre = genre;
    }

    public Book(int id, String bookTitle, LocalDate publishDate, int pageNum, String authors, int edition, String description, Genre genre) {
        this.id = id;
        this.bookTitle = bookTitle;
        this.publishDate = publishDate;
        this.pageNum = pageNum;
        this.authors = authors;
        this.edition = edition;
        this.description = description;
        this.genre = genre;
    }

}
