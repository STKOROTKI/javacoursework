package dsbook;

public enum UserType {
    Admin, Customer, Employee;
}
