package dsbook;

public enum Genre {
    FANTASY, SCI_FI, DRAMA, SCIENCE, ADVENTURE
}
