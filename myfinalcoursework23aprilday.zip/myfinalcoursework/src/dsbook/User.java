package dsbook;


import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;

@Getter
@Setter
@Entity
public abstract class User implements Serializable {
    @Id
    @GeneratedValue (strategy = GenerationType.IDENTITY)
    private String userId;
    private String Login;
    private String password;
    @Enumerated
    private UserType userType;
    private String usermail;
    private String userpostalcode;
    private String userphonenumber;

    public User(String userId, String login, String password, UserType userType,  String usermail, String userpostalcode, String userphonenumber) {
        this.userId = userId;
        Login = login;
        this.password = password;
        this.userType = userType;

        this.usermail = usermail;
        this.userpostalcode = userpostalcode;
        this.userphonenumber = userphonenumber;
    }

    public User(UserType userType, String login, String password, String usermail, String userpostalcode, String userphonenumber) {
        this.userType = userType;
        this.Login = login;
        this.password = password;


        this.usermail = usermail;
        this.userpostalcode = userpostalcode;
        this.userphonenumber = userphonenumber;
    }

    public User() {
    }


}

