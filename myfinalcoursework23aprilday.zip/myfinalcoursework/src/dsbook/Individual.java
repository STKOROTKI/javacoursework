package dsbook;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Entity;
import java.time.LocalDate;

@Entity
@Getter
@Setter
@NoArgsConstructor

public class Individual extends User{
    private String individname;
    private String individsurname;
    private LocalDate birthdate;

    public Individual(String userId, String login, String password, UserType userType,  String usermail, String userpostalcode, String userphonenumber, String individname, String individsurname, LocalDate birthdate) {
        super(userId, login, password, userType, usermail, userpostalcode, userphonenumber);
        this.individname = individname;
        this.individsurname = individsurname;
        this.birthdate = birthdate;
    }

    public Individual(UserType userType,  String login, String password, String usermail, String userpostalcode, String userphonenumber, String individname, String individsurname/*, LocalDate birthdate*/) {
        super(userType, login, password, usermail, userpostalcode, userphonenumber);
        this.individname = individname;
        this.individsurname = individsurname;
    //    this.birthdate = birthdate;
    }



    /* public Individual(String login, String password, UserType userType, String name, String surname) {
        super(login,
                password,
                userType);
        this.name = name;
        this.surname = surname;
        this.birthdate = birthdate;
    }*/

//    public Individual(String login, String password, UserType userType, String name, String surname) {
//        super(login, password, userType);
//        this.individname = name;
//        this.individsurname = surname;
//        this.birthdate = birthdate;
//    }
//
//    public Individual(String text, String text1, String text2, String text3, String text4, String text5) {
//    }
}
